.. ecm-module:: ../../modules/ECMCheckOutboundLicense.cmake
