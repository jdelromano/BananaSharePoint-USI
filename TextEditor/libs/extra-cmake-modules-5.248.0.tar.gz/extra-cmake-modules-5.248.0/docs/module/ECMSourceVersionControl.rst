.. ecm-module:: ../../modules/ECMSourceVersionControl.cmake
