.. ecm-module:: ../../modules/ECMAddTests.cmake
