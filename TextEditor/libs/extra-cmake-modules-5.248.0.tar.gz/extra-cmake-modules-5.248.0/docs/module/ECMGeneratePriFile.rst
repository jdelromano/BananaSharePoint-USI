.. ecm-module:: ../../modules/ECMGeneratePriFile.cmake
