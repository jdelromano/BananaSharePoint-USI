.. ecm-module:: ../../modules/ECMQtDeclareLoggingCategory.cmake
