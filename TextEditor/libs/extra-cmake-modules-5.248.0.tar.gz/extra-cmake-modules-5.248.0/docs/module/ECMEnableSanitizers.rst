.. ecm-module:: ../../modules/ECMEnableSanitizers.cmake
