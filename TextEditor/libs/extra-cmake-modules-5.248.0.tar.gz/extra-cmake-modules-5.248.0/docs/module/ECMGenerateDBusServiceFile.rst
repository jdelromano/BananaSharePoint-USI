.. ecm-module:: ../../modules/ECMGenerateDBusServiceFile.cmake
