.. ecm-module:: ../../modules/QtVersionOption.cmake
