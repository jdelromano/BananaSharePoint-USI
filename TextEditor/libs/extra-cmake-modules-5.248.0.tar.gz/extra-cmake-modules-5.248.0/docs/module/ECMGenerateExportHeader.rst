.. ecm-module:: ../../modules/ECMGenerateExportHeader.cmake
