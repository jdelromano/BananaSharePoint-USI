.. ecm-module:: ../../modules/CheckAtomic.cmake
