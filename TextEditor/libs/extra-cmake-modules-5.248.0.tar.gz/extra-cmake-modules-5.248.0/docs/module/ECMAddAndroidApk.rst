.. ecm-module:: ../../modules/ECMAddAndroidApk.cmake
