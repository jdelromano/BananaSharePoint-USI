.. ecm-module:: ../../modules/ECMConfiguredInstall.cmake
