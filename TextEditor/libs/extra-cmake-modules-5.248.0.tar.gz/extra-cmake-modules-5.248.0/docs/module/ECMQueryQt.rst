.. ecm-module:: ../../modules/ECMQueryQt.cmake
