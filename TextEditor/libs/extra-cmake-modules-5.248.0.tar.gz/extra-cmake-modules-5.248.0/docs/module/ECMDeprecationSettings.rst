.. ecm-module:: ../../modules/ECMDeprecationSettings.cmake
