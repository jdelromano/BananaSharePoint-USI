.. ecm-module:: ../../modules/ECMMarkAsTest.cmake
