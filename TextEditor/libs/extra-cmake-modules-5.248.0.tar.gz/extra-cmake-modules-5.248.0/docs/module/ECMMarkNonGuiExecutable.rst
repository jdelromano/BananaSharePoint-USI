.. ecm-module:: ../../modules/ECMMarkNonGuiExecutable.cmake
