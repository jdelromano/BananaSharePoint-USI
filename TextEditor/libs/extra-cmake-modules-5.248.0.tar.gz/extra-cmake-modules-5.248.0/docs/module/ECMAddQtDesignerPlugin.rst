.. ecm-module:: ../../modules/ECMAddQtDesignerPlugin.cmake
