.. ecm-module:: ../../find-modules/FindEGL.cmake
