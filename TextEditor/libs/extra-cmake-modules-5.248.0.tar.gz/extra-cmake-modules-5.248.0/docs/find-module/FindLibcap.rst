.. ecm-module:: ../../find-modules/FindLibcap.cmake
