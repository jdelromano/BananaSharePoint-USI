.. ecm-module:: ../../find-modules/FindLibExiv2.cmake
