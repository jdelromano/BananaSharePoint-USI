.. ecm-module:: ../../find-modules/Findgzip.cmake
