.. ecm-module:: ../../find-modules/FindGradle.cmake
