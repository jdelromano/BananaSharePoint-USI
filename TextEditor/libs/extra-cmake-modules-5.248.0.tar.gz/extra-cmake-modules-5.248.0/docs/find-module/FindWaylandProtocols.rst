.. ecm-module:: ../../find-modules/FindWaylandProtocols.cmake
