.. ecm-module:: ../../find-modules/FindWayland.cmake
