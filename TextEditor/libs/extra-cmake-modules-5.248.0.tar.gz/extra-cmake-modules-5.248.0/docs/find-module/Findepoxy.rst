.. ecm-module:: ../../find-modules/Findepoxy.cmake
