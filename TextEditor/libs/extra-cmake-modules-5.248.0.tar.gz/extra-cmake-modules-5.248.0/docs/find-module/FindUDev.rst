.. ecm-module:: ../../find-modules/FindUDev.cmake
