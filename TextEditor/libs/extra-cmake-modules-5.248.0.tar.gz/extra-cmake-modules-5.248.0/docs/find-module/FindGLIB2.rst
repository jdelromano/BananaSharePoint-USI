.. ecm-module:: ../../find-modules/FindGLIB2.cmake
