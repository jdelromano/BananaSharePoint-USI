.. ecm-module:: ../../find-modules/FindQtWaylandScanner.cmake
