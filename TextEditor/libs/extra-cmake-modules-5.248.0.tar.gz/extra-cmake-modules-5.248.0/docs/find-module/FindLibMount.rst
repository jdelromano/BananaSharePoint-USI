.. ecm-module:: ../../find-modules/FindLibMount.cmake
