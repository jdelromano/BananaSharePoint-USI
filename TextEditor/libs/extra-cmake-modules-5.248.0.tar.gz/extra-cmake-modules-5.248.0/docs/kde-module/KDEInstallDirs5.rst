.. ecm-module:: ../../kde-modules/KDEInstallDirs5.cmake
