.. ecm-module:: ../../kde-modules/KDEMetaInfoPlatformCheck.cmake
