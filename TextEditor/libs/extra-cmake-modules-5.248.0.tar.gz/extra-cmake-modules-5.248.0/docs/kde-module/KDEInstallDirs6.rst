.. ecm-module:: ../../kde-modules/KDEInstallDirs6.cmake
