.. ecm-module:: ../../kde-modules/KDECompilerSettings.cmake
