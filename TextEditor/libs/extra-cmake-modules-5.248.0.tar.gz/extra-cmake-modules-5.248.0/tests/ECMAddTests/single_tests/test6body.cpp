#include "testhelper.h"

void test_body()
{
    make_test_file("test6.txt");
}

