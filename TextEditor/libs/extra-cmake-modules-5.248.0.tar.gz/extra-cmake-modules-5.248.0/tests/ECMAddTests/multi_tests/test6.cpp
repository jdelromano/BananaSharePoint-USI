#include "testhelper.h"

int main()
{
    make_test_file("test6.txt");
    return 0;
}

