#include "testhelper.h"

int main()
{
    make_test_file("test9.txt");
    return 0;
}

